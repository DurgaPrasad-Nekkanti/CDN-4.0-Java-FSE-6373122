import React, { useState } from 'react';

export default function CurrencyConvertor() {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('');
  const [result, setResult] = useState('');

  // static conversion rates
  const inrToEuroRate = 90; // 1 EUR = 90 INR
  const euroToInrRate = 90; // same inverse

  const handleSubmit = (e) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (isNaN(val)) {
      setResult('Please enter a valid number for amount.');
      return;
    }
    const cur = currency.trim().toUpperCase();
    if (cur === 'INR') {
      const converted = (val / inrToEuroRate).toFixed(2);
      alert(`Coverting to Euro Amount is €${converted}...`);
      setResult(`${val} INR = €${converted}`);
    } else if (cur === 'EURO' || cur === 'EUR') {
      const converted = (val * euroToInrRate).toFixed(2);
      alert(`Coverting to INR Amount is ₹${converted}...`);
      setResult(`€${val} = ₹${converted}`);
    } else {
      setResult('Currency must be INR or EURO.');
    }
  };

  return (
    <div>
      <h1 style={{ color: 'green' }}>Currency Convertor!!!</h1>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 10 }}>
          <label style={{ display: 'inline-block', width: 80 }}>Amount:</label>
          <input
            type="text"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="e.g., 900"
            style={{ width: 200 }}
          />
        </div>
        <div style={{ marginBottom: 10 }}>
          <label style={{ display: 'inline-block', width: 80 }}>Currency:</label>
          <input
            type="text"
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            placeholder="INR or EURO"
            style={{ height: 50 ,width: 200 }}
          />
        </div>
        <button type="submit">Submit</button>
      </form>
      {result && (
        <p style={{ marginTop: 12, fontWeight: 'bold' }}>{result}</p>
      )}
      <p style={{ fontSize: 12, color: '#555' }}>
        (Using static rate: 1 EUR = {inrToEuroRate} INR)
      </p>
    </div>
  );
}

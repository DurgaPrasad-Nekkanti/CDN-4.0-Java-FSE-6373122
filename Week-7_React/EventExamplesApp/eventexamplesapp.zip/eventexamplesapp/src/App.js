import React from 'react';
import Counter from './Counter';
import CurrencyConvertor from './CurrencyConvertor';

function App() {
  return (
    <div
      style={{
        minHeight: '100vh',
        padding: 20,
        fontFamily: 'Arial, sans-serif',
        width: '100%',
        boxSizing: 'border-box',
      }}
    >
      <Counter />
      <div style={{ marginTop: 40 }}>
        <CurrencyConvertor />
      </div>
    </div>
  );
}

export default App;

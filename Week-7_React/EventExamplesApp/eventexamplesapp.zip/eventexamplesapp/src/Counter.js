import React from 'react';

class Counter extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 5 };
    this.increment = this.increment.bind(this);
    this.decrement = this.decrement.bind(this);
  }

  increment() {
    this.setState((prev) => ({ count: prev.count + 1 }));
    alert('Hello! Member1...');
  }

  decrement() {
    this.setState((prev) => ({ count: prev.count - 1 }));
  }

  render() {
    return (
      <div style={{ marginBottom: 30 }}>
        <div style={{ fontSize: 24, marginBottom: 12 }}>{this.state.count}</div>
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 12,          // even vertical spacing
            width: 160,       // uniform button container width
          }}
        >
          <button style={{ padding: '8px 12px' }} onClick={this.increment}>
            Increment
          </button>
          <button style={{ padding: '8px 12px' }} onClick={this.decrement}>
            Decrement
          </button>
          <button
            style={{ padding: '8px 12px' }}
            onClick={() => {
              alert('welcome');
            }}
          >
            Say welcome
          </button>
          <button
            style={{ padding: '8px 12px' }}
            onClick={(e) => {
              e.preventDefault();
              alert('I was clicked');
            }}
          >
            Click on me
          </button>
        </div>
      </div>
    );
  }
}

export default Counter;

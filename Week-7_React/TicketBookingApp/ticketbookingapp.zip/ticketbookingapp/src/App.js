import React, { useState } from 'react';
import './App.css';

function LoginButton({ onClick }) {
  return <button onClick={onClick}>Login</button>;
}

function LogoutButton({ onClick }) {
  return <button onClick={onClick}>Logout</button>;
}

function Greeting({ isLoggedIn }) {
  return isLoggedIn ? <UserGreeting /> : <GuestGreeting />;
}

function GuestGreeting() {
  const flights = [
    { id: 1, from: 'Delhi', to: 'Mumbai', time: '10:00 AM' },
    { id: 2, from: 'Hyderabad', to: 'Chennai', time: '1:30 PM' },
    { id: 3, from: 'Bangalore', to: 'Pune', time: '6:45 PM' }
  ];

  return (
    <div>
      <h1>Please sign up.</h1>
      <h3>Available Flights:</h3>
      <ul>
        {flights.map((flight) => (
          <li key={flight.id}>
            {flight.from} → {flight.to} at {flight.time}
          </li>
        ))}
      </ul>
    </div>
  );
}

function UserGreeting() {
  const [name, setName] = useState('');
  const [flight, setFlight] = useState('');
  const [message, setMessage] = useState('');

  const handleBooking = () => {
    if (name && flight) {
      setMessage(`Ticket booked for ${name} on flight ${flight}!`);
      alert(`Ticket booked for ${name} on flight ${flight}!`);
    } else {
      setMessage('Please enter name and select a flight.');
    }
  };

  return (
    <div>
      <h1>Welcome back! Book your tickets..</h1>
      <label>
        Name:{' '}
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </label>
      <br /><br />
      <label>
        Select Flight:{' '}
        <select value={flight} onChange={(e) => setFlight(e.target.value)}>
          <option value="">--Select--</option>
          <option value="Delhi to Mumbai">Delhi → Mumbai</option>
          <option value="Hyderabad to Chennai">Hyderabad → Chennai</option>
          <option value="Bangalore to Pune">Bangalore → Pune</option>
        </select>
      </label>
      <br /><br />
      <button onClick={handleBooking}>Book Ticket</button>
      <p style={{ color: 'green' }}>{message}</p>
    </div>
  );
}

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const button = isLoggedIn
    ? <LogoutButton onClick={() => setIsLoggedIn(false)} />
    : <LoginButton onClick={() => setIsLoggedIn(true)} />;

  return (
    <div className="app-container">
      <div style={{ marginBottom: 20 }}>
        <Greeting isLoggedIn={isLoggedIn} />
        {button}
      </div>
    </div>
  );
}

export default App;

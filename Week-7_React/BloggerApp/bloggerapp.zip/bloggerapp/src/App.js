import React from 'react';
import BookDetails from './BookDetails';
import BlogDetails from './BlogDetails';
import CourseDetails from './CourseDetails';
import { books } from './data/books';
import { blogs } from './data/blogs';
import { courses } from './data/courses';
import './App.css';

function App() {
  return (
    <div className="container">
      <div className="column">
        <CourseDetails courses={courses} />
      </div>
      <div className="column">
        <BookDetails books={books} />
      </div>
      <div className="column">
        <BlogDetails blogs={blogs} />
      </div>
    </div>
  );
}

export default App;
